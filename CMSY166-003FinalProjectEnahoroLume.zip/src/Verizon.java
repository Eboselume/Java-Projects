public class Verizon extends Carrier{
    

	public Verizon(){
		super("Verizon");
	}// end of constructor
    
    
    
}// end of subclass Verizon
