public class ATandT extends Carrier{
    
	public ATandT(){
		super("AT&T");
	}// end of constructor 
    
    
}// end of subclass AT&T