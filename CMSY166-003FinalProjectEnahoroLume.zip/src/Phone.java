abstract public class Phone {
    
    public abstract void initialize(String carrier, boolean memberCA);
    
}// end of class Phone
